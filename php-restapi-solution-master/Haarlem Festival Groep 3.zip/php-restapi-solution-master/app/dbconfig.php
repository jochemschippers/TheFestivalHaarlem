<?php
$servername = "mysql";
$username = "root";
$password = "secret123";
$database = "thefestivaldb";
