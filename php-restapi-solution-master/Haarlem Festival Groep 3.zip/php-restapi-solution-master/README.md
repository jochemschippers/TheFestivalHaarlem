# Haarlem Festival Assessment tweede kans groep 3

URL naar de website:
https://thehaarlemfestivalgroep3.000webhostapp.com/



## Inlog gegevens admin:

email: "admin@thefestival.com"

Password: "admin123"



## Inlog gegevens gebruiker:

email: mark@gmail.com

Password: mark123