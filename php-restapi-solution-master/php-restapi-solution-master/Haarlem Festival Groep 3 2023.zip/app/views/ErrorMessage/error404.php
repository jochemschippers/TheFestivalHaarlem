<div class="container" style="height: 75vh; top:100px;">
    <div class="row align-items-center h-100">
        <div class="col-md-8 offset-md-2 mt-5">
            <div class="card text-center">
                <div class="card-header">
                    <h2 class="card-title">Error 404: Event Not Found</h2>
                </div>
                <div class="card-body">
                    <p class="card-text">
                        Oops! It seems like you've wandered off the festival grounds and stumbled into uncharted territory. This stage isn't quite ready for showtime.<br><br>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>